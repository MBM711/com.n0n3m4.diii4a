#ifndef __HUD_BENCHTRACE_H__
#define __HUD_BENCHTRACE_H__

void Trace_StartTrace( int *results, int *finished, const char *pszServer );
void Trace_Think( void );

#endif // __HUD_BENCHTRACE_H__
