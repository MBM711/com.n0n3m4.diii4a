//========= Copyright (c) 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose:
//
// $NoKeywords: $
//=============================================================================

#ifndef __GAMESTUDIOMODELRENDERER_H__
#define __GAMESTUDIOMODELRENDERER_H__

/*
====================
CGameStudioModelRenderer

====================
*/
class CGameStudioModelRenderer : public CStudioModelRenderer
{
public:
	CGameStudioModelRenderer( void );
};

#endif // __GAMESTUDIOMODELRENDERER_H__
