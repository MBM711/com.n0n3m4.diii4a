//========= Copyright (c) 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose:
//
// $NoKeywords: $
//=============================================================================

#ifndef __VIEW_H__
#define __VIEW_H__

void V_StartPitchDrift( void );
void V_StopPitchDrift( void );

#endif // __VIEW_H__
