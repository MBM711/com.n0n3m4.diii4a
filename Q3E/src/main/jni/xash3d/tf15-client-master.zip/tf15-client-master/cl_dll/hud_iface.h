//========= Copyright (c) 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose:
//
// $NoKeywords: $
//=============================================================================

#ifndef __HUD_IFACE_H__
#define __HUD_IFACE_H__

#include "exportdef.h"
// redefine
// typedef int (*pfnUserMsgHook)( const char *pszName, int iSize, void *pbuf );
#include "wrect.h"
#include "../engine/cdll_int.h"
extern cl_enginefunc_t gEngfuncs;

#endif // __HUD_IFACE_H__
