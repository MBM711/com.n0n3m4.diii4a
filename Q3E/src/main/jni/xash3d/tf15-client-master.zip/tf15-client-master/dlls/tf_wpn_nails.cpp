#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "weapons.h"

// Velaron: TODO
CTFIncendiaryCRocket *CTFIncendiaryCRocket::CreateRpgRocket( Vector p_vecOrigin, Vector p_vecAngles, CBaseEntity *pOwner, CTFIncendiaryC *pLauncher )
{ 
	return 0;
}

CTFRpgRocket *CTFRpgRocket::CreateRpgRocket( Vector p_vecOrigin, Vector p_vecAngles, CBaseEntity *pOwner, CTFRpg *pLauncher )
{
	return 0;
}

CLaserSpot *CLaserSpot::CreateSpot( void )
{
	return 0;
}